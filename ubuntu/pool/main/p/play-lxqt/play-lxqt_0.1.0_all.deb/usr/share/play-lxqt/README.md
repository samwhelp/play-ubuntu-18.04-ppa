
# Play lxqt


## Usage - make


### help

``` sh
$ make
```

or

``` sh
$ make help
```


### install

``` sh
$ make install
```


### remove

``` sh
$ make remove
```


### pkg-install

``` sh
$ make pkg-install
```


### pkg-remove

``` sh
$ make pkg-remove
```


### conf-set

``` sh
$ make conf-set
```


### conf-reset

``` sh
$ make conf-reset
```
