
set -e ##

#echo $THE_BASE_DIR_PATH
source "$THE_BASE_DIR_PATH/base.sh"

base_var_init

base_var_dump

source "$THE_EXT_DIR_PATH/func.sh"
